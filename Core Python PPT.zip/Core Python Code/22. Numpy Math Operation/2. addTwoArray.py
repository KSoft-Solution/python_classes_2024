from numpy import *
a = array([101, 102, 103, 104, 105])
b = array([1, 2, 3, 4, 5])
c = a + b

for el in c:
	print(el)
print()