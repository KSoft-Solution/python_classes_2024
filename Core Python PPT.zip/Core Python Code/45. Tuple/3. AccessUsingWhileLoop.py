# Access Tuple using while Loop
a = (10, 21.3, 'Geekyshows')		

n = len(a)
i = 0
while i<n:
	print(a[i])
	i+=1