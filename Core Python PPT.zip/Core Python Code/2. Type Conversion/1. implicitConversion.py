a = 5
b = 2
value = a/b
print(value)
print(type(value))

x = 10
y = 5.5
total = x + y 
print(total)
print(type(total))

j = "Hello"
k = "Geeky Shows"
p = j + k
print(p)
print(type(p))

q = 20
u = '10'
r = q + u 
print(r)

m = 20
n = 'Geekyshows'
t = m + n 
print(t)
