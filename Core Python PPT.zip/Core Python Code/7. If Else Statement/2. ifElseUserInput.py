a = int(input("Enter Number Greater than 2: "))
if(a >= 2):
	print("Correct!! You have Entered:", a)
else:
	print("Wrong!! You have Entered:", a)