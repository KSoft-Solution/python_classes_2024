# Accessing Dictionary using for loop
stu = {101:'Rahul', 102:'Raj', 103:'Sonam'}

# Accessing Single Value
print(stu[101])

# Display Keys
for k in stu:
	print(k)
	
#Display Values
for k in stu:
	print(stu[k])