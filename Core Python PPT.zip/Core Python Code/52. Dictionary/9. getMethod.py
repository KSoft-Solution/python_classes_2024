# Dictionary - get() Method
stu = {101: 'Rahul', 102: 'Raj', 103: 'Sonam' }
print("Original Dict:")
print(stu)
print()

print(stu.get(101))

print(stu.get(104))

print(stu.get(104, 'GeekyShows'))
