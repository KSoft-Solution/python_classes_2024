# Dictionary

# Creating Empty Dictionary
d = {}

# Creating Dictionary with items
stu = {101: 'Rahul', 102: 'Raj', 103: 'Sonam' }
fees = {'rahul':2000, 'raj':3000, 'sonam':8000}

# Accessing value of dictionary
print(stu)
print(stu[101])
print(stu[102])
print(stu[103])

print()

print(fees)
print(fees['rahul'])
print(fees['raj'])
print(fees['sonam'])


