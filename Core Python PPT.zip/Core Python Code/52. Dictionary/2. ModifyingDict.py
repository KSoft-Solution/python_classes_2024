# Modifying Dictionary

stu = {101: 'Rahul', 102: 'Raj', 103: 'Sonam' }
print("Before Modification:")
print(stu)
print(id(stu))
print()

stu[102] = 'Python'
print("After Modification:")
print(stu)
print(id(stu))
print()



