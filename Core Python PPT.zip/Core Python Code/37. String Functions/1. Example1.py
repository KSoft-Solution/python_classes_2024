print("****** Upper Function ******")
name = "geekyshows"
str1 = name.upper()
print(name)
print(str1)

print("****** Lower Function ******")
name = "GEEKYSHOWS"
str1 = name.lower()
print(name)
print(str1)

print("****** Swapcase Function ******")
name = "geekyshows"
str1 = name.swapcase()
print(name)
print(str1)

print("****** Title Function ******")
name = "hello geekyshows how are you"
str1 = name.title()
print(name)
print(str1)