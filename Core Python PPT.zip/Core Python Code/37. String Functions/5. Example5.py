print("****** lstrip Function ******")
name = "   Geekyshows"
str1 = name.lstrip()
print(name)
print(str1)

print("****** rstrip Function ******")
name = "Geekyshows  "
str1 = name.rstrip()
print(name)
print(str1)

print("****** strip Function ******")
name = "   Geekyshows  "
str1 = name.strip()
print(name)
print(str1)