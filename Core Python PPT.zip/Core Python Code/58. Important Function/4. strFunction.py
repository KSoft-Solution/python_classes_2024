# str () Function
a = 10
print("Int:",a)
print(type(a))
new_a = str(a)
print("String:",new_a)
print(type(new_a))

print()

b = 10.56
print("Float:",b)
print(type(b))
new_b = str(b)
print("String:",new_b)
print(type(new_b))