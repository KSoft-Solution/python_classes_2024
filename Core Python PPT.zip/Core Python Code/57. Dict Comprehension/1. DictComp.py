# Dictionary Comprehension
lst = [(101, "Rahul"), (102, "Raj")]
dict1 = {k:v for k,v in lst}
print(dict1)
