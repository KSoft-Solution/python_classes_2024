# Nested While Loop
i = 1
while i<=3:
	print("Outer Loop", i)
	i+=1
	j = 1
	while j<=5:
		print("Inner Loop", j)
		j+=1

print("Rest of Code")