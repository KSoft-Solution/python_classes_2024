# While Loop
a = 1
while a<=10:
	print(a)
	a+=1
print("Rest of the Code")

a = 2
while a<=20:
	print(a)
	a+=2
print("Rest of the Code")