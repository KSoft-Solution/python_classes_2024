if 5>2:
	print("Greater")
	print("5 is greater than 2")
	if(6>2):
		print("6 is Greater than 2")
print("Rest of The Code")


			