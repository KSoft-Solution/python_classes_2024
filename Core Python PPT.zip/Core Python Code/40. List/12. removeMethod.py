#remove(element) method

a = [70, 10, 30, 10, 90, 'Geekyshows']

print("Before Remove:", a)

a.remove(10)

print("After Remove:", a)

for element in a:
	print(element)

