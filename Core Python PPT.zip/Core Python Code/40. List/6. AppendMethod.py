# Append Method
a = [10, 20, -50, 21.3, 'Geekyshows']

print("Before Appending:")
for element in a:
	print (element)

# Appending an element
a.append(100)
print()
print("After Appending")
for element in a:
	print (element)