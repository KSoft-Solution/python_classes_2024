a = [10, 20, -50, 21.3, 'Geekyshows']
print("Before Deletion: ")
print(a)
print()

# Deleting single element of List
print("After Deletion:")
del a[2]
print(a)
print()

# Deleting entire List
del a
print(a)		# It will show error as List a has been deleted 
