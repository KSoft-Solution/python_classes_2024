# For Loop with Else
st = "GeekyShows"
for ch in st:
	print(ch)
else:
	print("Else Part Executed")
print("Rest of the Code")