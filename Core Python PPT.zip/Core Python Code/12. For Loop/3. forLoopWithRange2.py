# for Loop with Range Function
a = range(5)
for i in a:
	print(i)

b = range(1, 5)
for i in b:
	print(i)

c = range(1, 10, 2)
for i in c:
	print(i)

n = range(-1, -10, -2)
for i in n:
	print(i)

r = range(5, 0, -1)
for i in r:
	print(i)

