# Nested Set Comprehension
st ={(i, j) for j in range(4,7) for i in range(6,8)}
print(st)
print(type(st))
