a = 10				#	0000 1010
b = 15				#	0000 1111	

print('~a = ', ~a)
print('a&b = ', a&b)
print('a|b = ', a|b)
print('a^b = ', a^b)
print('a<<2 = ', a<<2)
print('a>>2 = ', a>>2)
