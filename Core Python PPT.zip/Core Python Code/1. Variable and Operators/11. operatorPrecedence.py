value = (1+1)*2**4//3+4-1
print(value)