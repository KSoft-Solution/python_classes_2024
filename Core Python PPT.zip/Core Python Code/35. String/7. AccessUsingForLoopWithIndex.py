str1 = "GeekyShows"
for i in range(len(str1)):
	print(str1[i])

