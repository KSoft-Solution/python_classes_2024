str1 = "GeekyShows"
i = 0
while i < len(str1) :
	print(str1[i])
	i+=1

