# Pass Statement
if(5<2):
	pass
else:
	print("Else Part Do Something")
print("Rest of the Code")

print("*****************")	

i = 1
while i<=10 :
	if(i == 5):
		pass
	print(i)
	i+=1
print("Rest of the Code")