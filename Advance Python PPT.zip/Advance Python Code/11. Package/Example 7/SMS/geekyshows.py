# geekyshows Module

from Tech import work
work.tech_work()

