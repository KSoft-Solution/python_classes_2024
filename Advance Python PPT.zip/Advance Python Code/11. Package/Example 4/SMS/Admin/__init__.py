# Admin Package --> __init__ Module
__all__ = ['service', 'product']
