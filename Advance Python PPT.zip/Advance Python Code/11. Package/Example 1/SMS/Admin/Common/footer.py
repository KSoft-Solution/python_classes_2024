# Admin package --> Common package --> footer Module

def admin_common_footer():
	print("Admin Package --> Common Package --> footer Module")
	print("admin_common_footer Function")
	print()