# Tech Package --> work Module

def tech_work():
	print("Tech Package --> work Module")
	print("tech_work Function")
	print()