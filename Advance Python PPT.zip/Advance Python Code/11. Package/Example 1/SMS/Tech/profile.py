# Tech Package --> profile Module
def tech_profile():
	print("Tech Package --> profile Module")
	print("tech_profile Function")
	print()