# Creating Object of date Class
from datetime import date
d1 = date(year=2019, month=6, day=30)
d2 = date(2017, 4, 28)
print(d1)
print(d1.year)
print(d1.month)
print(d1.day)
print()
print(d2)
print(d2.year)
print(d2.month)
print(d2.day)