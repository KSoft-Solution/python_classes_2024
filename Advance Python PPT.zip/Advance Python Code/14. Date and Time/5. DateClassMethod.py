from datetime import date
cd1 = date.today()				# Calling Method using class name
print("Current Date:", cd1)
print("Date:", cd1.day)
print("Month:", cd1.month)
print("Year:", cd1.year)
print()