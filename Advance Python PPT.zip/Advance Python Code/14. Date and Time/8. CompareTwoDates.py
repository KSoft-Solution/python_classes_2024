# Comparing Two Dates
from datetime import date
d1 = date(2019, 6, 30)
d2 = date(2010, 6, 30)
print(d1==d2)
print(d1>d2)
print(d1<d2)
print(d1!=d2)
