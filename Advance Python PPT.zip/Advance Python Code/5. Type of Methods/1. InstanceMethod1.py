# Instance Method w/o Parameter
class Mobile:
	def show_model(self):			# Instance Method
		print("RealMe X")

realme = Mobile()
realme.show_model()					# Calling Instance Method