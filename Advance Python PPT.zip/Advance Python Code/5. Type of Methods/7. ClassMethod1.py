# Class Method w/o Parameter
class Mobile:
	@classmethod
	def show_model(cls):			# Class Method
		print("RealMe X")

realme = Mobile()
Mobile.show_model()					# Calling Class Method