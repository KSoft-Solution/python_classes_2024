# Static Method w/o Parameter
class Mobile:
	@staticmethod
	def show_model():			# Static Method
		print("RealMe X")

realme = Mobile()
Mobile.show_model()				# Calling Static Method