import os
print(os.getcwd())
os.chdir('mydir')
print(os.getcwd())