import os
os.rmdir('newdir')					# It will remove newdir
os.rmdir('yourdir/mychilddir')		# It will remove only mychilddir


