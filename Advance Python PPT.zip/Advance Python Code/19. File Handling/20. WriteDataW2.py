# Writing Data with w mode Example 2
f = open('student.txt', mode='w')
f.write('Hello ')
f.write('GeekyShows ')
f.write('How are you')
f.close()
print('Success')


