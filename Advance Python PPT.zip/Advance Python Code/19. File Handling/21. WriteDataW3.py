# Writing Data with w mode
f = open('student.txt', mode='w')
f.write('Hello\n')
f.write('GeekyShows\n')
f.write('How are you')
f.close()
print('Success')

