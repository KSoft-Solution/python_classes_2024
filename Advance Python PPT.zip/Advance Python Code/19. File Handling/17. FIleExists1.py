import os
print(os.path.isfile('student.txt'))