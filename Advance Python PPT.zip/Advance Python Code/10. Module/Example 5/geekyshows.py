# geekyshows.py <--- Main Module

from cal import a, name, add as s, sub			# Importing Cal Module

print("cal Module's variable:", a)	# Accessing Cal Module's Variable

name()								# Accessing Cal Module's Function

add = s(10,20)						# Accessing Cal Module's Function
print(add)

b = sub(20, 10)						# Accessing Cal Module's Function
print(b)
