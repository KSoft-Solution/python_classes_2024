#first.py  <--- first Module
class Myclass:
	def name(self):
		print("Name Method from first Module")

class Myschool:
	def show(self):
		print("Show Method from first Module")
		

	