# geekyshows.py <--- Main Module

from first import Myclass, Myschool			# Importing first Module

c = Myclass()		# Creating Myclass Object
c.name()

s = Myschool()		# Creating Myschool Object
s.show()

