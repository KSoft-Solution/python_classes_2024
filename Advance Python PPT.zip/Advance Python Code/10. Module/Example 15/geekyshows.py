# geekyshows.py <--- Main Module

from first import Myclass, Myschool				# Importing first Module
from second import Mycollege					# Importing second Module

c = Myclass()			# Creating Myclass Object - first Module
c.name()

s = Myschool()		# Creating Myschool Object - first Module
s.show()

s = Mycollege()		# Creating Myschool Object - second Module
s.disp()
